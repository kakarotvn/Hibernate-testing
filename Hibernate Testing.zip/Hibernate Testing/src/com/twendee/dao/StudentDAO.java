package com.twendee.dao;

import com.twendee.hibernate.Student;
import com.twendee.utils.HibernateUtil;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.query.Query;

import java.util.List;

public class StudentDAO {
    public static List<Student> getAllStudent(){
        Session session = HibernateUtil.getSessionFactory().openSession();
        List<Student> students = null;
        try{
            //create query
            final String hql = "select st from Student st";
            Query query = session.createQuery(hql);
            //Get all students
            students = query.list();
        }catch (HibernateException e){
            System.err.println(e);
        }finally {
            session.close();
        }
        return students;
    }
}
