import com.twendee.dao.StudentDAO;
import com.twendee.hibernate.Student;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Student> rs = StudentDAO.getAllStudent();

            System.out.println(rs.toString());

    }
}
